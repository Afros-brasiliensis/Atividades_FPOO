#pragma once
#include "Interface.h"

int main() {
	Interface interfaceLoja;
	interfaceLoja.iniciar();
	return 0;
}